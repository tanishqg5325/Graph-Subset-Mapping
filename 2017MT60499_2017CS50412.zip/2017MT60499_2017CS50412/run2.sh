#!/bin/bash

./main2 $1
