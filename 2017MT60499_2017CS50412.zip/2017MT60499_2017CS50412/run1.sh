#!/bin/bash

./main1 $1
